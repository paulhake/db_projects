--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.5
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE master_sql_course;
--
-- Name: master_sql_course; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE master_sql_course WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE master_sql_course OWNER TO postgres;

\connect master_sql_course

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    make character varying(10)
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses (
    course_no character varying(5),
    course_title character varying(20),
    credits integer
);


ALTER TABLE public.courses OWNER TO postgres;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    department character varying(100) NOT NULL,
    division character varying(100)
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(50),
    hire_date date,
    department character varying(17),
    gender character varying(1),
    salary integer,
    region_id integer
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: fruit_imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fruit_imports (
    id integer,
    name character varying(20),
    season character varying(10),
    state character varying(20),
    supply integer,
    cost_per_unit numeric
);


ALTER TABLE public.fruit_imports OWNER TO postgres;

--
-- Name: fruits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fruits (
    fruit_name character varying(10)
);


ALTER TABLE public.fruits OWNER TO postgres;

--
-- Name: professors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.professors (
    last_name character varying(20),
    department character varying(12),
    salary integer,
    hire_date date
);


ALTER TABLE public.professors OWNER TO postgres;

--
-- Name: regions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.regions (
    region_id integer NOT NULL,
    region character varying(20),
    country character varying(20)
);


ALTER TABLE public.regions OWNER TO postgres;

--
-- Name: student_enrollment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_enrollment (
    student_no integer,
    course_no character varying(5)
);


ALTER TABLE public.student_enrollment OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    student_no integer,
    student_name character varying(20),
    age integer
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: teach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teach (
    last_name character varying(20),
    course_no character varying(5)
);


ALTER TABLE public.teach OWNER TO postgres;

--
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cars (make) FROM stdin;
\.
COPY public.cars (make) FROM '$$PATH$$/3300.dat';

--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses (course_no, course_title, credits) FROM stdin;
\.
COPY public.courses (course_no, course_title, credits) FROM '$$PATH$$/3296.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (department, division) FROM stdin;
\.
COPY public.departments (department, division) FROM '$$PATH$$/3292.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employee_id, first_name, last_name, email, hire_date, department, gender, salary, region_id) FROM stdin;
\.
COPY public.employees (employee_id, first_name, last_name, email, hire_date, department, gender, salary, region_id) FROM '$$PATH$$/3294.dat';

--
-- Data for Name: fruit_imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fruit_imports (id, name, season, state, supply, cost_per_unit) FROM stdin;
\.
COPY public.fruit_imports (id, name, season, state, supply, cost_per_unit) FROM '$$PATH$$/3301.dat';

--
-- Data for Name: fruits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fruits (fruit_name) FROM stdin;
\.
COPY public.fruits (fruit_name) FROM '$$PATH$$/3302.dat';

--
-- Data for Name: professors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.professors (last_name, department, salary, hire_date) FROM stdin;
\.
COPY public.professors (last_name, department, salary, hire_date) FROM '$$PATH$$/3298.dat';

--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.regions (region_id, region, country) FROM stdin;
\.
COPY public.regions (region_id, region, country) FROM '$$PATH$$/3293.dat';

--
-- Data for Name: student_enrollment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_enrollment (student_no, course_no) FROM stdin;
\.
COPY public.student_enrollment (student_no, course_no) FROM '$$PATH$$/3297.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (student_no, student_name, age) FROM stdin;
\.
COPY public.students (student_no, student_name, age) FROM '$$PATH$$/3295.dat';

--
-- Data for Name: teach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teach (last_name, course_no) FROM stdin;
\.
COPY public.teach (last_name, course_no) FROM '$$PATH$$/3299.dat';

--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (region_id);


--
-- PostgreSQL database dump complete
--

